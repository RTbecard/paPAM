Before running, make sure you have the correct version of MCR installed:
- R2017b 64-bit

You can download it directly from the MATLAB website:
- https://www.mathworks.com/products/compiler/matlab-runtime.html

